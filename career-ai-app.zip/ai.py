import openai
import os

# Načítaj OpenAI API kľúč z env premenných
openai.api_key = os.getenv("OPENAI_API_KEY")

def generate_cover_letter_prompt(cv_text: str, job_position: str, company_name: str = "a company") -> str:
    prompt = f"Based on the following resume:
\n{cv_text}\n\nWrite a professional cover letter for the position '{job_position}' at '{company_name}'."
    return prompt

def get_ai_cover_letter(cv_text: str, job_position: str, company_name: str = "a company") -> str:
    prompt = generate_cover_letter_prompt(cv_text, job_position, company_name)
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a career assistant AI that writes excellent cover letters."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7,
        max_tokens=600
    )
    return response.choices[0].message.content.strip()