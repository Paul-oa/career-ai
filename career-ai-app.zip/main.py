from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from passlib.hash import bcrypt
import aiofiles
import os
import uuid
from datetime import datetime

from database import SessionLocal, engine
from models import Base, UserDB, ResumeDB, CoverLetterDB

Base.metadata.create_all(bind=engine)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/register")
def register_user(email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    hashed_password = bcrypt.hash(password)
    user = UserDB(email=email, password_hash=hashed_password)
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"user_id": str(user.id)}

@app.post("/resume/upload")
async def upload_resume(user_id: str = Form(...), file: UploadFile = File(...), db: Session = Depends(get_db)):
    user = db.query(UserDB).filter(UserDB.id == uuid.UUID(user_id)).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    file_location = f"uploaded_files/{uuid.uuid4()}_{file.filename}"
    os.makedirs("uploaded_files", exist_ok=True)
    async with aiofiles.open(file_location, "wb") as buffer:
        content = await file.read()
        await buffer.write(content)
    parsed_text = f"Simulated text extracted from {file.filename}"
    resume = ResumeDB(user_id=user.id, file_url=file_location, parsed_text=parsed_text)
    db.add(resume)
    db.commit()
    db.refresh(resume)
    return {"resume_id": str(resume.id)}

@app.post("/cover-letter/generate")
def generate_cover_letter(user_id: str = Form(...), resume_id: str = Form(...), job_position: str = Form(...), company_name: str = Form(None), db: Session = Depends(get_db)):
    resume = db.query(ResumeDB).filter(ResumeDB.id == uuid.UUID(resume_id), ResumeDB.user_id == uuid.UUID(user_id)).first()
    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found or does not belong to user")
    ai_output = f"Generated cover letter for {job_position} at {company_name or 'a company'} based on resume."
    letter = CoverLetterDB(
        user_id=resume.user_id,
        resume_id=resume.id,
        job_position=job_position,
        company_name=company_name,
        generated_text=ai_output,
    )
    db.add(letter)
    db.commit()
    db.refresh(letter)
    return {"cover_letter_id": str(letter.id), "generated_text": ai_output}

@app.get("/cover-letters/{user_id}")
def get_user_cover_letters(user_id: str, db: Session = Depends(get_db)):
    letters = db.query(CoverLetterDB).filter(CoverLetterDB.user_id == uuid.UUID(user_id)).all()
    return letters