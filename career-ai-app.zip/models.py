import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from database import Base

class UserDB(Base):
    __tablename__ = "users"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(Text, nullable=False)
    resumes = relationship("ResumeDB", back_populates="user")
    cover_letters = relationship("CoverLetterDB", back_populates="user")

class ResumeDB(Base):
    __tablename__ = "resumes"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    file_url = Column(Text, nullable=False)
    parsed_text = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("UserDB", back_populates="resumes")
    cover_letters = relationship("CoverLetterDB", back_populates="resume")

class CoverLetterDB(Base):
    __tablename__ = "cover_letters"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    resume_id = Column(UUID(as_uuid=True), ForeignKey("resumes.id"), nullable=True)
    job_position = Column(String, nullable=False)
    company_name = Column(String, nullable=True)
    generated_text = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("UserDB", back_populates="cover_letters")
    resume = relationship("ResumeDB", back_populates="cover_letters")