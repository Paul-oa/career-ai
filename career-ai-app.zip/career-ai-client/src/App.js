import React, { useState } from "react";
import axios from "axios";

function App() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [userId, setUserId] = useState(null);
  const [file, setFile] = useState(null);
  const [resumeId, setResumeId] = useState(null);
  const [job, setJob] = useState("");
  const [company, setCompany] = useState("");
  const [coverLetter, setCoverLetter] = useState("");

  const register = async () => {
    const formData = new FormData();
    formData.append("email", email);
    formData.append("password", password);
    const res = await axios.post("/register", formData);
    setUserId(res.data.user_id);
  };

  const uploadResume = async () => {
    const formData = new FormData();
    formData.append("user_id", userId);
    formData.append("file", file);
    const res = await axios.post("/resume/upload", formData);
    setResumeId(res.data.resume_id);
  };

  const generateLetter = async () => {
    const formData = new FormData();
    formData.append("user_id", userId);
    formData.append("resume_id", resumeId);
    formData.append("job_position", job);
    formData.append("company_name", company);
    const res = await axios.post("/cover-letter/generate", formData);
    setCoverLetter(res.data.generated_text);
  };

  return (
    <div>
      <h1>Career AI App</h1>
      <div>
        <h2>1. Register</h2>
        <input placeholder="email" onChange={e => setEmail(e.target.value)} />
        <input placeholder="password" type="password" onChange={e => setPassword(e.target.value)} />
        <button onClick={register}>Register</button>
      </div>
      <div>
        <h2>2. Upload Resume</h2>
        <input type="file" onChange={e => setFile(e.target.files[0])} />
        <button onClick={uploadResume}>Upload</button>
      </div>
      <div>
        <h2>3. Generate Cover Letter</h2>
        <input placeholder="Job Position" onChange={e => setJob(e.target.value)} />
        <input placeholder="Company Name" onChange={e => setCompany(e.target.value)} />
        <button onClick={generateLetter}>Generate</button>
        <pre>{coverLetter}</pre>
      </div>
    </div>
  );
}

export default App;