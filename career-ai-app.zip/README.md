# Career AI App

Aplikácia na generovanie motivačných listov a analýzu kariéry pomocou umelej inteligencie.

## ✅ Funkcie

- Registrácia používateľov
- Upload životopisu
- Generovanie AI motivačných listov
- Ukladanie výsledkov do PostgreSQL
- Asynchrónna práca so súbormi
- API prístup k histórii

## 🚀 Spustenie

1. Skopíruj `.env` a vyplň:
   ```
   cp .env .env.local
   ```

2. Nainštaluj závislosti:
   ```
   pip install -r requirements.txt
   ```

3. Spusti aplikáciu:
   ```
   uvicorn main:app --reload
   ```

4. Dokumentácia bude dostupná na:
   ```
   http://localhost:8000/docs
   ```

## 🔗 Pripojenie k PostgreSQL

V `.env` nastav:
```
DATABASE_URL=postgresql://username:password@localhost:5432/career_ai
```

## 🧠 AI generovanie

Funguje cez OpenAI (GPT-4). Vyžaduje platný `OPENAI_API_KEY`.